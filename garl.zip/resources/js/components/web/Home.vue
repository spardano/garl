<template>
    <div class="container-fluid">
        <div class="card">
				<div class="card-body">
					Hi, you are logged in!
				</div>
			</div>
        
    </div>
</template>

<script>
    export default {
        data: function () {
            return {
            }
        },
        mounted(){
            this.LOADING = false
        },
        methods: {

        }
    }

</script>
