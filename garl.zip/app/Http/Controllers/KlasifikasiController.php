<?php

namespace App\Http\Controllers;

use App\Aturan;
use App\Kecamatan;
use App\Kelurahan;
use App\Kriteria;
use App\Mclass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class KlasifikasiController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    
    public function proses(Request $req){
        $rules = [
            'kelurahan_id'  => 'required|exists:kelurahan,id',
            'details'       => 'required|array'
        ];

        $this->validate($req, $rules);

        $classify = Mclass::UNCLASSIFIED;

        $details    = array_filter($req->input("details"), function($d){ return ($d != null); });
        $params     = array_keys($details);
        $rules      = Aturan::with('details')->whereHas('details', function($q) use ($params){
            return $q->whereIn("param", $params);
        })->get();
        
        $nonNullRules = [];
        foreach($rules as $r){
            $complete = true;
            if(count($params) != count($r->details)) continue;
            $nonNullRules[] = $r;
        }
        $normal     = $this->normalize($params, $details);
        $normalize  = $normal['normal'];
        $rekom      = $normal['rekom'];
        foreach($nonNullRules as $classRules){
            $match = true;
            foreach($classRules->details as $rule){
                if(!isset($normalize[$rule->param]) || ($rule->value != $normalize[$rule->param])) $match = false;
            }

            if($match) $classify = $classRules->class;
        }

        $kelurahan = Kelurahan::find($req->input("kelurahan_id"));
        $kelurahan->class   = $classify;
        $kelurahan->data    = json_encode($normal);
        $kelurahan->dataraw = json_encode($details);
        $kelurahan->save();
        return $kelurahan;
    }

    private function normalize($params, $details){
        $normal = [];
        $rekom  = [];
        $kriteria = Kriteria::whereIn("id", $params)->with("details")->get();
        foreach($details as $normKey => $norm){
            foreach($kriteria as $kri){
                if($normKey != $kri->id) continue;
                
                foreach($kri->details as $kd){
                    $k          = clone $kri;
                    unset($k->details);
                    $kd->kriteria       = $k->toArray();
                    if($kri->type == 'numeric'){
                        if($kd->min == -1){
                            if($norm <= $kd->max){
                                $rekom[$normKey]    = $kd->toArray();
                                $normal[$normKey]   = $kd->keterangan;//$norm - $kd->min;
                            }
                        }elseif($kd->max == -1){
                            if($norm >= $kd->min){
                                $rekom[$normKey]    = $kd->toArray();
                                $normal[$normKey]   = $kd->keterangan;//$norm - $kd->min;
                            }
                        }else{
                            if($norm >= $kd->min && $norm <= $kd->max){
                                $rekom[$normKey]    = $kd->toArray();
                                $normal[$normKey]   = $kd->keterangan;//$norm - $kd->min;
                            }
                        }
                    }else{
                        if(strtolower($norm) == strtolower($kd->min) || strtolower($norm) == strtolower($kd->max)){
                            $rekom[$normKey]    = $kd->toArray();
                            $normal[$normKey]   = $kd->keterangan;
                        }
                    }
                }
            }
        }
        return ['normal' => $normal, 'rekom' => $rekom];
    }

    public function result($id)
    {
        $kelurahan = Kelurahan::with(['kecamatan.kabupaten', 'kelas'])->findOrFail($id);
        return response()->json($kelurahan);
    }
}
