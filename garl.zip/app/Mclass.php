<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mclass extends Model
{
    const UNCLASSIFIED = 4;
    protected $table = "class";

}
